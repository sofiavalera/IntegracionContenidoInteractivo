
/*
  Anything put in this file is ran in the Node context,
  not the browser context, and it's the first thing ran
  when your application launches, before the window ever
  loads.
*/
